﻿using System;

namespace DeclareVariables
{
    class DeclareVariables
    {
        static void Main()
        {
            ushort firstNumber = 52130;
            sbyte secondNumber = -115;
            int thirdNumber = 4825932;
            byte fourthNumber = 97;
            short fifthNumber = -10000;
            Console.WriteLine("ushort variable: " + firstNumber +
                "; \n sbyte variable: "+ secondNumber + 
                "; \n int variable: "+ thirdNumber + 
                "; \n byte variable: "+ fourthNumber + 
                "; \n short variable: "+ fifthNumber);
        }
    }
}

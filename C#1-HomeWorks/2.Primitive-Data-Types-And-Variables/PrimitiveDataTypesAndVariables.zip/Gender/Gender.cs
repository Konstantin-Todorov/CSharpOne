﻿using System;

namespace Gender
{
    class Gender
    {
        static void Main()
        {
            bool isFemale = true;
            Console.Write("Am I female? ");
            Console.WriteLine( isFemale ? "Yes" : "No");
        }
    }
}

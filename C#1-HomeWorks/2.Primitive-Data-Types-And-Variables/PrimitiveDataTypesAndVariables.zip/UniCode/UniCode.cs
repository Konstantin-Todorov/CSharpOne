﻿using System;
namespace UniCode
{
    class UniCode
    {
        static void Main()
        {
            char hex = '\u0042' ;
            Console.WriteLine("The character with Unicode code (hexadecimal 48) is: " + hex);
        }
    }
}

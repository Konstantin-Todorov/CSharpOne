﻿using System;

namespace FloatOrDouble
{
    class FloatOrDouble
    {
        static void Main()
        {
            float firstFloat = 3456.091f;
            float secondFloat = 12.345f;
            double firstDouble = 34.567839023;
            double secondDouble = 8923.1234857;

            Console.WriteLine("These are the flaots:" + firstFloat + " ; " + secondFloat + ".\n"
            + "These are the doubles:" + firstDouble + ";" + secondDouble + " . ");
        }
    }
}

﻿using System;
using System.Threading.Tasks;

namespace DecIntoHex
{
    class DecIntoHex
    {
        static void Main()
        {
            int hex = 0xFE;
            Console.WriteLine("This is the decimal value of '0xFE' = " + hex);
        }
    }
}

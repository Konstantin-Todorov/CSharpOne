﻿using System;

namespace MyName
{
    class printMyName
    {
        static void Main()
        {
            Console.Title = "Print My Name ";
            Console.WriteLine( " My name is Konstantin ! ");
        }
    }
}

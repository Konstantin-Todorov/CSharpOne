﻿using System;
namespace PrintFirstAndLastName
{
    class printFirstAndLast
    {
        static void Main()
        {
            Console.Title = "PrintFirstAndLastName";
            Console.WriteLine("Konstantin");
            Console.WriteLine("Todorov");
        }
    }
}

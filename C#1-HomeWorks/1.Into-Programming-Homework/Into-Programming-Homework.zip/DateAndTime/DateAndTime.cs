﻿using System;


class DateTime
{
    static void Main()
    
    {
     
        Console.WriteLine(System.DateTime.Now);
    }
}

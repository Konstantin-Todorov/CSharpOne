﻿using System;

class HelloCSharp
{
    static void Main()
    {
        Console.Title = "PrintHelloCSharp";
        Console.WriteLine("Hello, C#!");
    }
}
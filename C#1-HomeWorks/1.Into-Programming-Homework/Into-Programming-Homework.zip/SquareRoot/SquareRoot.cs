﻿using System;

namespace SquareRoot
{
    class SquareRoot
    {
        static void Main()

        {
            const int n = 12345;
            Console.WriteLine(Math.Sqrt(n));
        
        }
    }
}
